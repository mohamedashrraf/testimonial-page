//سرعة حركة الصور
$(document).ready(function(){
    $('.carousel').carousel({
        interval:2000
    });
});